using UnityEngine;

public class QuaternionDemo : MonoBehaviour
{
    [Header("��ʾ����")]
    public GameObject rotCube;

    [Header("��ת����")]
    public Vector3 eulerStart;
    public Vector3 eulerEnd;
    [Range(0, 1)] public float t;

    private Quaternion qStart;
    private Quaternion qEnd;

    [Header("ʵʱ��Ϣ(ֻ��)")]
    public Quaternion currentQuat;
    public Vector3 currentEuler;

    private bool isLerping = false;

    void Start()
    {
        UpdateQuatFromEuler();
    }

    void Update()
    {
        // ��������
        if (Input.GetKeyDown(KeyCode.Space))
        {
            isLerping = !isLerping;
            t = 0;
        }

        if (isLerping)
        {
            t += Time.deltaTime * 0.3f;
            t = Mathf.Clamp01(t);
            //��Ԫ�������ֵ Slerp�����ģ�����ͨLerp����
            currentQuat = Quaternion.Slerp(qStart, qEnd, t);
            rotCube.transform.rotation = currentQuat;
        }

        currentQuat = rotCube.transform.rotation;
        currentEuler = rotCube.transform.eulerAngles;

        // R������
        if (Input.GetKeyDown(KeyCode.R))
        {
            t = 0;
            isLerping = false;
            UpdateQuatFromEuler();
            rotCube.transform.rotation = qStart;
        }
    }

    //��ŷ����תΪ��Ԫ��
    [ContextMenu("ˢ����Ԫ��")]
    void UpdateQuatFromEuler()
    {
        qStart = Quaternion.Euler(eulerStart);
        qEnd = Quaternion.Euler(eulerEnd);
    }
}